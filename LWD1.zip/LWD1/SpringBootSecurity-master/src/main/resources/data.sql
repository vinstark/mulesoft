INSERT INTO user (username, email, password, role)
VALUES ('dinesh', 'admin@doj.com', '$2a$10$ebyC4Z5WtCXXc.HGDc1Yoe6CLFzcntFmfse6/pTj7CeDY5I05w16C', 'ADMIN');